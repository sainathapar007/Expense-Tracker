import streamlit as st
import mysql.connector
import pandas as pd
import plotly.express as px
import hashlib
import datetime
import extra_streamlit_components as stx
import base64
import os

# Page Configuration
st.set_page_config(
    page_title="Expense Tracker & Analytics",
    page_icon="💸",
    layout="wide"
)

# --- DATABASE SETUP & SECURITY ---
def get_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="YOUR_PASSWORD_HERE",  # Replace with your MySQL root password
        database="expense_tracker"
    )

def make_hashes(password):
    return hashlib.sha256(str.encode(password)).hexdigest()

def check_hashes(password, hashed_text):
    if make_hashes(password) == hashed_text:
        return hashed_text
    return False

def add_user(username, password):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO users (username, password_hash) VALUES (%s, %s)", (username, make_hashes(password)))
    conn.commit()
    conn.close()

def login_user(username, password):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT password_hash FROM users WHERE username = %s", (username,))
    data = cursor.fetchone()
    conn.close()
    if data:
        return check_hashes(password, data[0])
    return False

def get_total_users():
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM users")
        total = cursor.fetchone()[0]
        conn.close()
        return total
    except Exception:
        return 0

def get_total_system_expenses():
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM expenses")
        total = cursor.fetchone()[0]
        conn.close()
        return total
    except Exception:
        return 0

def add_expense(date, category, amount, description, username):
    conn = get_connection()
    cursor = conn.cursor()
    query = "INSERT INTO expenses (expense_date, category, amount, description, username) VALUES (%s, %s, %s, %s, %s)"
    cursor.execute(query, (date, category, amount, description, username))
    conn.commit()
    conn.close()

def load_data(username):
    conn = get_connection()
    query = f"SELECT * FROM expenses WHERE username = '{username}'"
    df = pd.read_sql(query, conn)
    conn.close()
    return df

def delete_expense(expense_id, username):
    conn = get_connection()
    cursor = conn.cursor()
    query = "DELETE FROM expenses WHERE id = %s AND username = %s"
    cursor.execute(query, (expense_id, username))
    conn.commit()
    conn.close()

def get_image_base64(image_path):
    if os.path.exists(image_path):
        with open(image_path, "rb") as img_file:
            return base64.b64encode(img_file.read()).decode()
    return None    

# --- COOKIE MANAGER SETUP ---
cookie_manager = stx.CookieManager()
cached_username = cookie_manager.get(cookie="username")

if 'logged_in' not in st.session_state:
    if cached_username:
        st.session_state['logged_in'] = True
        st.session_state['username'] = cached_username
    else:
        st.session_state['logged_in'] = False

# --- UI ROUTING (LOGIN vs DASHBOARD) ---
if not st.session_state['logged_in']:
    st.title("🔒 Daily Expense Tracker - Portal")
    
    menu = ["Login", "Sign Up"]
    choice = st.selectbox("Select Action", menu)

    if choice == "Login":
        st.subheader("Login to your account")
        username = st.text_input("Username")
        password = st.text_input("Password", type='password')
        if st.button("Login", type="primary"):
            if login_user(username, password):
                st.session_state['logged_in'] = True
                st.session_state['username'] = username
                
                expire_date = datetime.datetime.now() + datetime.timedelta(days=30)
                cookie_manager.set("username", username, expires_at=expire_date)
                st.rerun() 
            else:
                st.error("Incorrect username or password.")

    elif choice == "Sign Up":
        st.subheader("Create a new account")
        new_user = st.text_input("Username")
        new_password = st.text_input("Password", type='password')
        if st.button("Sign Up", type="primary"):
            try:
                add_user(new_user, new_password)
                st.success("Account created successfully! Switch to the Login tab to continue.")
            except Exception:
                st.error("Username already exists. Please choose a different one.")

else:
    # --- LOGGED-IN SIDEBAR ---
    st.sidebar.title(f"👤 {st.session_state['username']}")
    if st.sidebar.button("Logout"):
        st.session_state['logged_in'] = False
        cookie_manager.delete("username")
        st.rerun()
        
    st.sidebar.markdown("---")
    st.sidebar.header("➕ Add New Expense")
    
    my_categories = ["Vegetables", "Transport", "Medical", "Entertainment", "House Rent & Light Bills", "Groceries", "Other"]
    
    with st.sidebar.form("expense_form"):
        date = st.date_input("Date")
        category = st.selectbox("Category", my_categories)
        amount = st.number_input("Amount", min_value=0.0, format="%.2f")
        description = st.text_input("Description (Optional)")
        submit = st.form_submit_button("Save Expense")

        if submit:
            add_expense(date, category, amount, description, st.session_state['username'])
            st.sidebar.success("Expense logged successfully!")
            st.rerun()

    # --- MAIN DASHBOARD TABS ---
    tab_analytics, tab_data, tab_about = st.tabs([
        "📈 Analytics & Charts", 
        "📋 Data Records", 
        "👨‍💻 Developer & App Info"
    ])

    df = load_data(st.session_state['username'])

    # === TAB 1: ANALYTICS ===
    with tab_analytics:
        st.header("Expense Analytics")
        if not df.empty:
            df['expense_date'] = pd.to_datetime(df['expense_date'])
            df['month_year'] = df['expense_date'].dt.strftime('%B %Y')

            unique_months = ["All Time"] + df['month_year'].unique().tolist()
            filter_categories = ["All Categories"] + my_categories

            col1, col2 = st.columns(2)
            with col1:
                selected_month = st.selectbox("📅 Filter by Month:", unique_months, key="analytics_month")
            with col2:
                selected_category = st.selectbox("🏷️ Filter by Category:", filter_categories, key="analytics_cat")

            filtered_df = df.copy()
            if selected_month != "All Time":
                filtered_df = filtered_df[filtered_df['month_year'] == selected_month]
            if selected_category != "All Categories":
                filtered_df = filtered_df[filtered_df['category'] == selected_category]

            total_spent = filtered_df['amount'].sum()
            avg_spent = filtered_df['amount'].mean() if not filtered_df.empty else 0.0
            top_category = filtered_df.groupby('category')['amount'].sum().idxmax() if not filtered_df.empty else "None"

            m1, m2, m3 = st.columns(3)
            m1.metric("💰 Total Spent", f"Rs {total_spent:,.2f}")
            m2.metric("📊 Average Transaction", f"Rs {avg_spent:,.2f}")
            m3.metric("🔥 Top Category", top_category)

            st.markdown("---")

            if not filtered_df.empty:
                chart_col1, chart_col2 = st.columns(2)
                with chart_col1:
                    category_totals = filtered_df.groupby('category')['amount'].sum().reset_index()
                    fig_pie = px.pie(
                        category_totals, values='amount', names='category',
                        title="Spending Distribution", hole=0.42
                    )
                    fig_pie.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)")
                    st.plotly_chart(fig_pie, use_container_width=True)

                with chart_col2:
                    daily_totals = filtered_df.groupby('expense_date')['amount'].sum().reset_index()
                    fig_bar = px.bar(
                        daily_totals, x='expense_date', y='amount',
                        title="Daily Spending Activity", text_auto='.2s'
                    )
                    fig_bar.update_layout(paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)")
                    st.plotly_chart(fig_bar, use_container_width=True)
            else:
                st.info("No expense entries match the selected filters.")
        else:
            st.info("No expenses found. Add your first entry from the sidebar!")

    # === TAB 2: DATA TABLE & DELETE ===
    with tab_data:
        st.header("Expense Records")
        if not df.empty:
            display_df = df.copy()
            display_df['expense_date'] = pd.to_datetime(display_df['expense_date'])

            st.dataframe(
                display_df,
                column_config={
                    "id": st.column_config.NumberColumn("Record ID", format="%d"),
                    "expense_date": st.column_config.DateColumn("Date", format="YYYY-MM-DD"),
                    "category": st.column_config.TextColumn("Category"),
                    "amount": st.column_config.NumberColumn("Amount (Rs)", format="Rs %.2f"),
                    "description": st.column_config.TextColumn("Description"),
                    "username": None
                },
                hide_index=True,
                use_container_width=True
            )

            st.markdown("---")
            st.subheader("🗑️ Remove Entry")
            del_col1, del_col2 = st.columns([1, 3])
            with del_col1:
                delete_id = st.number_input("Enter Record ID to delete:", min_value=1, step=1, format="%d")
            with del_col2:
                st.write("")
                st.write("")
                if st.button("Confirm Deletion", type="primary"):
                    if delete_id in display_df['id'].values:
                        delete_expense(delete_id, st.session_state['username'])
                        st.success(f"Record #{delete_id} deleted successfully.")
                        st.rerun()
                    else:
                        st.error("Specified ID not found in your records.")
        else:
            st.info("No records to display.")

    # === TAB 3: DEVELOPER & APP INFO ===
    with tab_about:
        # Custom CSS for modern card and badge styling
        st.markdown("""
        <style>
        .dev-card {
            background-color: #1e212b;
            border-radius: 16px;
            padding: 28px;
            margin-bottom: 24px;
            border: 1px solid rgba(255, 255, 255, 0.08);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.25);
        }
        .dev-header {
            display: flex !important;
            flex-direction: column !important;
            align-items: center !important;
            justify-content: center !important;
            text-align: center !important;
            width: 100% !important;
        }

        .dev-avatar {
            font-size: 54px;
            background: #283046;
            width: 90px;
            height: 90px;
            line-height: 90px;
            border-radius: 50%;
            margin: 0 auto 15px auto;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 3px solid #00D4FF;
        }
        .dev-title {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 4px;
            color: #FAFAFA;
            text-align: center !important;
        }

       .dev-subtitle {
            font-size: 16px;
            font-weight: 600;
            color: #00D4FF;
            margin-bottom: 12px;
            text-align: center !important;
        }
        .dev-bio {
            color: #b0b8c4;
            max-width: 680px;
            margin: 0 auto 20px auto;
            line-height: 1.6;
            text-align: center !important;
        }
        .social-link {
            display: inline-block;
            text-decoration: none;
            padding: 8px 18px;
            border-radius: 8px;
            margin: 0 6px;
            font-weight: 600;
            color: #fff !important;
            font-size: 14px;
        }
        .btn-gh {
            background: #2b3137;
        }
        .btn-in {
            background: #0077b5;
        }
        .tech-pill {
            display: inline-block;
            background: rgba(0, 212, 255, 0.12);
            color: #00D4FF;
            padding: 6px 14px;
            margin: 4px;
            border-radius: 18px;
            font-size: 13px;
            font-weight: 600;
            border: 1px solid rgba(0, 212, 255, 0.25);
        }
        </style>
        """, unsafe_allow_html=True)

        # 1. Live System Status Bar
        st.subheader("📊 System & Application Status")
        stat_col1, stat_col2, stat_col3 = st.columns(3)
        stat_col1.metric("👥 Active Registered Users", get_total_users())
        stat_col2.metric("📝 Total Entries Processed", get_total_system_expenses())
        stat_col3.metric("⚙️ System Architecture", "MySQL + Streamlit")

        st.markdown("---")

        # 2. Main Developer Profile Card
        # Get the image (Make sure the file name matches exactly what is in your folder!)
        img_base64 = get_image_base64("sai image.png") 
        
        # Determine what to show in the circle (Photo if found, Emoji if not)
        if img_base64:
            avatar_html = f'<img src="data:image/png;base64,{img_base64}" style="width: 100%; height: 100%; object-fit: cover; border-radius: 50%;">'
        else:
            avatar_html = "👨‍💻"

        st.markdown(f"""
        <div class="dev-card">
            <div class="dev-header">
                <div class="dev-avatar">
                    {avatar_html}
                </div>
                <div class="dev-title">Sainath Apar</div>
                <div class="dev-subtitle">Computer Science & Engineering Student</div>
                <p class="dev-bio">
                    Python Developer • Database Architecture • Data Analytics • Web Application Development
                </p>
                <div>
                    <a href="https://github.com/sainathapar007" target="_blank" class="social-link btn-gh">💻 GitHub</a>
                    <a href="https://www.linkedin.com/in/sainathapar" target="_blank" class="social-link btn-in">🔗 LinkedIn</a>
                </div>
            </div>
        </div>
        """, unsafe_allow_html=True)

        # 3. Two-Column Information Cards
        info_col1, info_col2 = st.columns(2)

        with info_col1:
            st.markdown("""
            <div class="dev-card">
                <h4>👋 About the Developer</h4>
                <p style="color: #b0b8c4; line-height: 1.6;">
                    Computer Science & Engineering student focused on building scalable Python applications, 
                    relational database design, and end-to-end data analytics solutions.
                </p>
                <p style="color: #b0b8c4; line-height: 1.6; margin-bottom: 0;">
                    Experienced in combining backend database management with responsive client interfaces to solve everyday real-world utility challenges.
                </p>
            </div>
            """, unsafe_allow_html=True)

        with info_col2:
            st.markdown("""
            <div class="dev-card">
                <h4>🛠️ Engineering Highlights</h4>
                <ul style="color: #b0b8c4; line-height: 1.7; padding-left: 18px; margin-bottom: 0;">
                    <li>Relational database schema modeling & normalization in MySQL</li>
                    <li>Row-level multi-tenant user authentication with SHA-256</li>
                    <li>Persistent browser session management with Cookie components</li>
                    <li>Interactive data visualization pipelines using Plotly Express</li>
                    <li>Dynamic parameterized queries ensuring SQL injection defense</li>
                </ul>
            </div>
            """, unsafe_allow_html=True)

        # 4. Tech Stack Badges
        st.markdown("""
        <div class="dev-card">
            <h4>💻 Technologies Used</h4>
            <div>
                <span class="tech-pill">Python</span>
                <span class="tech-pill">Streamlit</span>
                <span class="tech-pill">MySQL</span>
                <span class="tech-pill">Pandas</span>
                <span class="tech-pill">Plotly Express</span>
                <span class="tech-pill">Hashlib (SHA-256)</span>
                <span class="tech-pill">Extra-Streamlit-Components</span>
                <span class="tech-pill">HTML5 & CSS3</span>
                <span class="tech-pill">Git & GitHub</span>
            </div>
        </div>
        """, unsafe_allow_html=True)

        # 5. Project Information & Disclaimer
        st.markdown("""
        <div class="dev-card">
            <h4>💸 About Expense Tracker</h4>
            <p style="color: #b0b8c4; line-height: 1.6;">
                A full-stack, multi-user financial tracking system that provides daily expense logging, categorization, 
                dynamic date/category filtering, real-time spending metrics, and interactive analytics. Built as a comprehensive engineering project.
            </p>
            <div style="margin-top: 15px; padding: 12px 16px; background: rgba(255, 193, 7, 0.12); border-left: 4px solid #ffc107; border-radius: 6px; color: #ffd56b;">
                <strong>Project Notice:</strong> Designed for personal utility and academic evaluation. All local financial records remain encrypted and segregated on a per-user basis.
            </div>
        </div>
        """, unsafe_allow_html=True)

        st.markdown("<p style='text-align: center; color: #6c757d; font-size: 13px; margin-top: 20px;'>© 2026 Daily Expense Tracker • Developed by Sainath Apar</," 
        "B.Tech Student"  \
        "p>", unsafe_allow_html=True)